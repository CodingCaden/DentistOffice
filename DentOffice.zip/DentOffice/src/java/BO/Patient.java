/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 * @author Ma'Caden Miles
 * 10/30/21-12/2/21
 * CIST 2373
 */
/*********************************************************
* Patient Class is used to store Patients
* *******************************************************/
public class Patient {
    
    private String patId;
    private String patPassword;
    private String patFirstName;
    private String patLastName;
    private String patAddress;
    private String patEmail;
    private String patIns;
    public Appointment appoint = new Appointment();
    
    
    public Patient(){
        patId = "";
        patPassword = "";
        patFirstName = "";
        patLastName = "";
        patAddress = "";
        patEmail = "";
        patIns = "";
    }
    
    public Patient(String i, String pw, String fn, String ln, String ad, String em, String ins){
        patId = i;
        patPassword = pw;
        patFirstName = fn;
        patLastName = ln;
        patAddress = ad;
        patEmail = em;
        patIns = ins;
    }
    
// Behaviors
public void setpatId(String i){patId=i;}
public String getpatId() {return patId; }
//
public void setpatPassword(String pw){patPassword=pw;}
public String getpatPassword() {return patPassword; }
//
public void setpatFirstName(String fn){patFirstName=fn;}
public String getpatFirstName() {return patFirstName; }
//
public void setpatLastName(String ln){patLastName=ln;}
public String getpatLastName() {return patLastName; }
//
public void setpatAddress(String ad){patAddress=ad;}
public String getpatAddress() {return patAddress; }
//
public void setpatEmail(String em){patEmail=em;}
public String getpatEmail() {return patEmail; }
//
public void setpatIns(String ins){patIns=ins;}
public String getpatIns() {return patIns; }





public void display() {
			System.out.println("ID             =   "+ patId);
			System.out.println("Password     =   "+ patPassword);
			System.out.println("First Name      =   "+ patFirstName);
                        System.out.println("Last Name      =   "+ patLastName);
			System.out.println("Address       =    "+ patAddress);
			System.out.println("Email            =   "+ patEmail);
                        System.out.println("Insurance            =   "+ patIns);
                        appoint.display();
		}
/*********************************************************
* SelectDB is used to select the Patient
* *******************************************************/
public void selectDB(String i) {
    patId =i;
    try {    //Load DB Driver
        Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
        Connection c1 = DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\Caden\\Desktop\\DentistOfficeMDB.MDB") ;
//Execute SQL Statement
Statement stmt = c1.createStatement();
ResultSet rs = stmt.executeQuery("Select * from Patients where patId = '" + i+"'");
//Process ResultSet
rs.next();
patPassword = rs.getString("passwd");
patFirstName = rs.getString("firstName");
patLastName = rs.getString("lastName");
patAddress = rs.getString("addr");
patEmail = rs.getString("email");
patIns = rs.getString("insCo");
c1.close();
	}
    catch(Exception se) {
        System.out.println(se);
    }
    getAppointment();
} //end selectDB()
/************************************************************
* Insert DB is used to insert a new Patient into Database
* **********************************************************/
public void insertDB(String i,String pw, String fn, String ln, String ad, String em, String ins){
        
        patId = i;
        patPassword = pw;
        patFirstName = fn;
        patLastName = ln;
        patAddress = ad;
        patEmail = em;
        patIns = ins;
        
       
        try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c2 = DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\Caden\\Desktop\\DentistOfficeMDB.MDB") ;
            
            Statement stmt = c2.createStatement();
            String sql = "INSERT INTO Patients (patId,passwd,firstName,lastName,addr,email,insCo) values('"+getpatId()+"',"+
                                                      "'"+getpatPassword()+"',"+ 
                                                      "'"+getpatFirstName()+"',"+ 
                                                      "'"+getpatLastName()+"',"+ 
                                                      "'"+getpatAddress()+"',"+
                                                      "'"+getpatEmail()+"',"+ 
                                                      "'"+getpatIns()+"')"; 
            System.out.println(sql);
            int n1 = stmt.executeUpdate(sql);
            if (n1==1)
                System.out.println("INSERT Successful!!!");
            else
                System.out.println("INSERT FAILED***********");
            c2.close();
        }
        catch(Exception e1){
            System.out.println(e1);
        }
      
    }//end insertDB()
/*********************************************************
* DeleteDB is used to delete a Patient in the Database
* *******************************************************/
public void deleteDB(){
         
       
        try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c3 = DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\Caden\\Desktop\\DentistOfficeMDB.MDB");
            
            Statement stmt = c3.createStatement();
            String sql = "Delete from Patients where patId='"+getpatId()+"'";
            System.out.println(sql);
            int n = stmt.executeUpdate(sql);
            if (n==1)
                System.out.println("DELETE Successful!!!");
            else
                System.out.println("DELETE FAILED***********");
            c3.close();
        }
        catch(Exception e1){
            System.out.println(e1);
        }
      
    }//end deleteDB()
/*********************************************************
* getappointment is used to get appointments for patients
* *******************************************************/
public void getAppointment(){
     
    try {    //Load DB Driver
        Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
        Connection c1 = DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\Caden\\Desktop\\DentistOfficeMDB.MDB") ;
//Execute SQL Statement
Statement stmt = c1.createStatement();
ResultSet rs = stmt.executeQuery("Select * from Appointments where patId ='"+ getpatId() +"'");
//Process ResultSet
String appt;
Appointment a1;
while (rs.next()) {
    
        appoint.selectDB(getpatId());
        appoint.setdateTime(rs.getString("apptDateTime"));
        appoint.setdenId(rs.getString("dentId"));
        appoint.setprocCode(rs.getString("procCode"));
    }

c1.close();
	}
    catch(Exception se) {
        System.out.println(se);
    }
 }
/*********************************************************
* UpdateDB is used to update patients in the database
* *******************************************************/
public void updateDB() {
            
            try{
                Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
                
               Connection con4 = DriverManager.getConnection
                       ("jdbc:ucanaccess://C:\\Users\\Caden\\Desktop\\DentistOfficeMDB.MDB");
               
            System.out.println("Database Connected");
            Statement stmt = con4.createStatement();

            String sql4 = "Update Patients set passwd = '"+getpatPassword()+"',"+
                                                "firstName = '"+getpatFirstName()+"',"+
                                                "lastName ='"+getpatLastName()+"',"+
                                                "addr = '"+getpatAddress()+"',"+
                                                "email = '"+getpatEmail()+"',"+
                                                "insCo = '"+getpatIns() + "' " +
                                                "Where patId ='"+getpatId()+"'";
            System.out.println(sql4);
            System.out.println("Data set");
            int n = stmt.executeUpdate(sql4);
            if(n==1)
                System.out.println("UPDATE Successful!!!");
            else
                System.out.println("UPDATE Failed************");
            con4.close();
            }
            catch(Exception e1){
                System.out.println(e1);
            }
    
        }//end updateDB()





public static void main(String args[]) {
	
	Patient p1;
        p1 = new Patient();
        
        p1.selectDB("A911");
        //p1.insertDB("a667", "1234", "firstname", "last", "address", "email", "insurance");
        //p1.selectDB("a667");
        //p1.deleteDB();
        //p1.setpatFirstName("testfn");
        //p1.updateDB();
        p1.display();
        
}
}


