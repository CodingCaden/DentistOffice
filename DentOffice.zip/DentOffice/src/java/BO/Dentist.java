/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 * @author Ma'Caden Miles
 * 10/30/21-12/2/21
 * CIST 2373
 */
/*********************************************************
* Dentist class is used to hold Dentists
* *******************************************************/
public class Dentist {
    
    private String denId;
    private String denPassword;
    private String denFirstName;
    private String denLastName;
    private String denEmail;
    private String denOffice;
    public AppointmentList appointL = new AppointmentList();
    
    
    public Dentist(){
        denId = "";
        denPassword = "";
        denFirstName = "";
        denLastName = "";
        denEmail = "";
        denOffice = "";
    }
    
    public Dentist(String i, String pw, String fn, String ln,String em, String of){
        denId = i;
        denPassword = pw;
        denFirstName = fn;
        denLastName = ln;
        denEmail = em;
        denOffice = of;
    }
    
// Behaviors
public void setdenId(String i){denId=i;}
public String getdenId() {return denId; }
//
public void setdenPassword(String pw){denPassword=pw;}
public String getdenPassword() {return denPassword; }
//
public void setdenFirstName(String fn){denFirstName=fn;}
public String getdenFirstName() {return denFirstName; }
//
public void setdenLastName(String ln){denLastName=ln;}
public String getdenLastName() {return denLastName; }
//
public void setdenEmail(String em){denEmail=em;}
public String getdenEmail() {return denEmail; }
//
public void setdenOffice(String of){denOffice=of;}
public String getdenOffice() {return denOffice; }

public void display() {
			System.out.println("ID             =   "+ denId);
			System.out.println("Password     =   "+ denPassword);
			System.out.println("First Name      =   "+ denFirstName);
                        System.out.println("Last Name      =   "+ denLastName);
			System.out.println("Email            =   "+ denEmail);
                        System.out.println("Office            =   "+ denOffice);
                        appointL.displayList();
		}

/*********************************************************
* SelectDB is used to select the Dentist
* *******************************************************/
public void selectDB(String i) {
    denId =i;
    try {    //Load DB Driver
        Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
        Connection c1 = DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\Caden\\Desktop\\DentistOfficeMDB.MDB") ;
//Execute SQL Statement
Statement stmt = c1.createStatement();
ResultSet rs = stmt.executeQuery("Select * from Dentists where id = '" + i+"'");
//Process ResultSet
rs.next();
denPassword = rs.getString("passwd");
denFirstName = rs.getString("firstName");
denLastName = rs.getString("lastName");
denEmail = rs.getString("email");
denOffice = rs.getString("office");
c1.close();
	}
    catch(Exception se) {
        System.out.println(se);
    }
    getAppointments();
} //end selectDB()
/******************************************************************
* getappointments is used to get the appointments from the database
* ****************************************************************/
public void getAppointments(){
     
    try {    //Load DB Driver
        Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
        Connection c1 = DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\Caden\\Desktop\\DentistOfficeMDB.MDB") ;
//Execute SQL Statement
Statement stmt = c1.createStatement();
ResultSet rs = stmt.executeQuery("Select * from Appointments where dentId ='"+ getdenId() +"'");
//Process ResultSet
String an;
Appointment a1;
while (rs.next()) {
        an = rs.getString("patId");
        a1 = new Appointment();
        a1.selectDB(an);
        appointL.addAppointment(a1);
    }

c1.close();
	}
    catch(Exception se) {
        System.out.println(se);
    }
 }

/************************************************************
* Insert DB is used to insert a new Dentist into the Database
* **********************************************************/
public void insertDB(String i,String pw, String fn, String ln, String em, String of){
        
        denId = i;
        denPassword = pw;
        denFirstName = fn;
        denLastName = ln;
        denEmail = em;
        denOffice = of;
        
       
        try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c2 = DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\Caden\\Desktop\\DentistOfficeMDB.MDB") ;
            
            Statement stmt = c2.createStatement();
            String sql = "INSERT INTO Dentists (Id,passwd,firstName,lastName,email,office) values('"+getdenId()+"',"+
                                                      "'"+getdenPassword()+"',"+ 
                                                      "'"+getdenFirstName()+"',"+ 
                                                      "'"+getdenLastName()+"',"+ 
                                                      "'"+getdenEmail()+"',"+ 
                                                      "'"+getdenOffice()+"')"; 
            System.out.println(sql);
            int n1 = stmt.executeUpdate(sql);
            if (n1==1)
                System.out.println("INSERT Successful!!!");
            else
                System.out.println("INSERT FAILED***********");
            c2.close();
        }
        catch(Exception e1){
            System.out.println(e1);
        }
      
    }//end insertDB()
/*********************************************************
* DeleteDB is used to delete a Dentist in Database
* *******************************************************/
public void deleteDB(){
         
       
        try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c3 = DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\Caden\\Desktop\\DentistOfficeMDB.MDB");
            
            Statement stmt = c3.createStatement();
            String sql = "Delete from Dentists where Id='"+getdenId()+"'";
            System.out.println(sql);
            int n = stmt.executeUpdate(sql);
            if (n==1)
                System.out.println("DELETE Successful!!!");
            else
                System.out.println("DELETE FAILED***********");
            c3.close();
        }
        catch(Exception e1){
            System.out.println(e1);
        }
      
    }//end deleteDB()
/*********************************************************
* UpdateDB is used to update Dentists in database
* *******************************************************/
public void updateDB() {
            
            try{
                Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
                
               Connection con4 = DriverManager.getConnection
                       ("jdbc:ucanaccess://C:\\Users\\Caden\\Desktop\\DentistOfficeMDB.MDB");
               
            System.out.println("Database Connected");
            Statement stmt = con4.createStatement();

            String sql4 = "Update Dentists set passwd = '"+getdenPassword()+"',"+
                                                "firstName = '"+getdenFirstName()+"',"+
                                                "lastName ='"+getdenLastName()+"',"+
                                                "email = '"+getdenEmail()+"',"+
                                                "office = '"+getdenOffice() + "' " +
                                                "Where id ='"+getdenId()+"'";
            System.out.println(sql4);
            System.out.println("Data set");
            int n = stmt.executeUpdate(sql4);
            if(n==1)
                System.out.println("UPDATE Successful!!!");
            else
                System.out.println("UPDATE Failed************");
            con4.close();
            }
            catch(Exception e1){
                System.out.println(e1);
            }
    
        }//end updateDB()

public static void main(String args[]) {
	
	Dentist d1;
        d1 = new Dentist();
        
        d1.selectDB("D201");
        //d1.insertDB("d655", "1234", "firstname", "last", "email","655");
        //d1.selectDB("d655");
        //d1.deleteDB();
        //d1.setdenFirstName("testfn");
        //d1.updateDB();
        d1.display();
        
}
}
