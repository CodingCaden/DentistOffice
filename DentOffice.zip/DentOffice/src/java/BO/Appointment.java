/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 * @author Ma'Caden Miles
 * 10/30/21-12/2/21
 * CIST 2373
 */
/*********************************************************
* Appointment Class is used to store Patients Appointments
* *******************************************************/
public class Appointment {
    
    
    private String dateTime;
    private String patId;
    private String denId;
    private String procCode;
    
    
    public Appointment(){
        dateTime = "";
        patId = "";
        denId = "";
        procCode = "";
    }
    
    public Appointment(String dt, String pid, String did, String pr){
        dateTime = dt;
        patId = pid;
        denId = did;
        procCode = pr;
    }
    
// Behaviors
public void setdateTime(String dt){dateTime=dt;}
public String getdateTime() {return dateTime; }
//
public void setpatId(String pid){patId=pid;}
public String getpatId() {return patId; }
//
public void setdenId(String did){denId=did;}
public String getdenId() {return denId; }
//
public void setprocCode(String pr){procCode=pr;}
public String getprocCode() {return procCode; }

public void display() {
			System.out.println("Date/Time             =   "+ dateTime);
			System.out.println("Patient ID     =   "+ patId);
			System.out.println("Dentist ID      =   "+ denId);
                        System.out.println("Procedure Code      =   "+ procCode);
                        
		}
/*********************************************************
* SelectDB is used to select the appointment
* *******************************************************/
public void selectDB(String i) {
    patId =i;
    try {    //Load DB Driver
        Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
        Connection c1 = DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\Caden\\Desktop\\DentistOfficeMDB.MDB") ;
//Execute SQL Statement
Statement stmt = c1.createStatement();
ResultSet rs = stmt.executeQuery("Select * from Appointments where patId = '" + i+"'");
//Process ResultSet
rs.next();
dateTime = rs.getString("apptDateTime");
denId = rs.getString("dentId");
procCode = rs.getString("procCode");

c1.close();
	}
    catch(Exception se) {
        System.out.println(se);
    }
} //end selectDB()

/************************************************************
* Insert DB is used to insert a new appointment into the Database
* **********************************************************/
public void insertDB(String dt,String pid, String did, String pr){
        
        dateTime = dt;
        patId = pid;
        denId = did;
        procCode = pr;
        
       
        try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c2 = DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\Caden\\Desktop\\DentistOfficeMDB.MDB") ;
            
            Statement stmt = c2.createStatement();
            String sql = "INSERT INTO Appointments (apptDateTime,patId,dentId,procCode) values('"+getdateTime()+"',"+
                                                      "'"+getpatId()+"',"+ 
                                                      "'"+getdenId()+"',"+ 
                                                      "'"+getprocCode()+"')"; 
            System.out.println(sql);
            int n1 = stmt.executeUpdate(sql);
            if (n1==1)
                System.out.println("INSERT Successful!!!");
            else
                System.out.println("INSERT FAILED***********");
            c2.close();
        }
        catch(Exception e1){
            System.out.println(e1);
        }
      
    }//end insertDB()
/*********************************************************
* DeleteDB is used to delete an appointment in Database
* *******************************************************/
public void deleteDB(){
         
       
        try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c3 = DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\Caden\\Desktop\\DentistOfficeMDB.MDB");
            
            Statement stmt = c3.createStatement();
            String sql = "Delete from Appointments where patId='"+getpatId()+"'";
            System.out.println(sql);
            int n = stmt.executeUpdate(sql);
            if (n==1)
                System.out.println("DELETE Successful!!!");
            else
                System.out.println("DELETE FAILED***********");
            c3.close();
        }
        catch(Exception e1){
            System.out.println(e1);
        }
      
    }//end deleteDB()

/*********************************************************
* UpdateDB is used to update appointments in database
* *******************************************************/
public void updateDB() {
            
            try{
                Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
                
               Connection con4 = DriverManager.getConnection
                       ("jdbc:ucanaccess://C:\\Users\\Caden\\Desktop\\DentistOfficeMDB.MDB");
               
            System.out.println("Database Connected");
            Statement stmt = con4.createStatement();

            String sql4 = "Update Appointments set patId = '"+getpatId()+"',"+
                                                "apptDateTime = '"+getdateTime()+"',"+
                                                "dentId ='"+getdenId()+"',"+
                                                "procCode = '"+getprocCode() + "' " +
                                                "Where patId ='"+getpatId()+"'";
            System.out.println(sql4);
            System.out.println("Data set");
            int n = stmt.executeUpdate(sql4);
            if(n==1)
                System.out.println("UPDATE Successful!!!");
            else
                System.out.println("UPDATE Failed************");
            con4.close();
            }
            catch(Exception e1){
                System.out.println(e1);
            }
    
        }//end updateDB()
public static void main(String args[]) {
	
	Appointment a1;
        a1 = new Appointment();
        
        //a1.selectDB("A911");
        //a1.insertDB("Date,/Time", "a789", "d789", "P789");
        //a1.selectDB("a789");
        //a1.deleteDB();
        
        a1.display();
        
}
}
