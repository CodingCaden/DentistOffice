/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 * @author Ma'Caden Miles
 * 10/30/21-12/2/21
 * CIST 2373
 */
/*********************************************************
* procedure Class is used to store Procedures
* *******************************************************/
public class Procedure {
    
    private String prCode;
    private String prName;
    private String prDesc;
    private String cost;
    
    
    public Procedure(){
        prCode = "";
        prName = "";
        prDesc = "";
        cost = "";
    }
    
    public Procedure(String prc, String prn, String prd, String co){
        prCode = prc;
        prName = prn;
        prDesc = prd;
        cost = co;
    }
    
// Behaviors
public void setprCode(String prc){prCode=prc;}
public String getprCode() {return prCode; }
//
public void setprName(String prn){prName=prn;}
public String getprName() {return prName; }
//
public void setprDesc(String prd){prDesc=prd;}
public String getprDesc() {return prDesc; }
//
public void setcost(String co){cost=co;}
public String getcost() {return cost; }

public void display() {
			System.out.println("Procedure Code             =   "+ prCode);
			System.out.println("Procedure Name     =   "+ prName + "\n");
			System.out.println("Procedure Description:         \n"+ prDesc + "\n");
                        System.out.println("Cost      =   "+ "$" + cost);
                        
		}
/*********************************************************
* SelectDB is used to select the procedure
* *******************************************************/
public void selectDB(String i) {
    prCode =i;
    try {    //Load DB Driver
        Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
        Connection c1 = DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\Caden\\Desktop\\DentistOfficeMDB.MDB") ;
//Execute SQL Statement
Statement stmt = c1.createStatement();
ResultSet rs = stmt.executeQuery("Select * from Procedures where procCode = '" + i+"'");
//Process ResultSet
rs.next();
prName = rs.getString("procName");
prDesc = rs.getString("procDesc");
cost = rs.getString("cost");

c1.close();
	}
    catch(Exception se) {
        System.out.println(se);
    }
} //end selectDB()

/************************************************************
* Insert DB is used to insert a new Procedure into the Database
* **********************************************************/
public void insertDB(String prc,String prn, String prd, String co){
        
        prCode = prc;
        prName = prn;
        prDesc = prd;
        cost =co;
        
       
        try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c2 = DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\Caden\\Desktop\\DentistOfficeMDB.MDB") ;
            
            Statement stmt = c2.createStatement();
            String sql = "INSERT INTO Procedures (procCode,procName,procDesc,cost) values('"+getprCode()+"',"+
                                                      "'"+getprName()+"',"+ 
                                                      "'"+getprDesc()+"',"+ 
                                                      "'"+getcost()+"')"; 
            System.out.println(sql);
            int n1 = stmt.executeUpdate(sql);
            if (n1==1)
                System.out.println("INSERT Successful!!!");
            else
                System.out.println("INSERT FAILED***********");
            c2.close();
        }
        catch(Exception e1){
            System.out.println(e1);
        }
      
    }//end insertDB()
/*********************************************************
* DeleteDB is used to delete the procedure from the database
* *******************************************************/
public void deleteDB(){
         
       
        try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection c3 = DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\Caden\\Desktop\\DentistOfficeMDB.MDB");
            
            Statement stmt = c3.createStatement();
            String sql = "Delete from Procedures where procCode='"+getprCode()+"'";
            System.out.println(sql);
            int n = stmt.executeUpdate(sql);
            if (n==1)
                System.out.println("DELETE Successful!!!");
            else
                System.out.println("DELETE FAILED***********");
            c3.close();
        }
        catch(Exception e1){
            System.out.println(e1);
        }
      
    }//end deleteDB()
public static void main(String args[]) {
	
	Procedure p1;
        p1 = new Procedure();
        
        //p1.selectDB("P114");
        //p1.insertDB("P567", "Name", "desc", "2.99");
        p1.selectDB("P567");
        p1.deleteDB();
        
        p1.display();
        
}
}
