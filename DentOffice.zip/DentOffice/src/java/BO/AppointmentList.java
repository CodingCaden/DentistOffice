/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BO;

/**
 * @author Ma'Caden Miles
 * 10/30/21-12/2/21
 * CIST 2373
 */
/************************************************************************
* AppointmentList Class is used to store patient appointments into a list
* **********************************************************************/
public class AppointmentList {
    public int count; // # of accounts in list
    public Appointment appArr[] = new Appointment[10];
    
    
/*********************************************************************
* addAppointment is used to add an appointment to the appointment list
* *******************************************************************/
    public void addAppointment(Appointment a1){
        
        appArr[count] = a1;
        count++;
    }
    
    public void displayList(){
        for (int x=0; x<count; x++) {
		appArr[x].display(); 
        }
        
        
}
    
    public static void main(String args[]) { 
        AppointmentList alist = new AppointmentList();

	Appointment a = new Appointment("7777", "3001","SAV","500.00");
	Appointment b = new Appointment("8888", "3002","CHK","700.00");

	alist.addAppointment(a);
	alist.addAppointment(b);

	alist.displayList();  //prints the list
    }
}
