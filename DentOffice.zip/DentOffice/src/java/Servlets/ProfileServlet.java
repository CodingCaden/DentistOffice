/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import BO.Patient;
import BO.Dentist;
import javax.servlet.RequestDispatcher;

/**
 * @author Ma'Caden Miles
 * 10/30/21-12/2/21
 * CIST 2373
 */
public class ProfileServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            
            String id = request.getParameter("Id");
            
            if(id.startsWith("A")){
                
                Patient p1 = new Patient();
        String FirstName = request.getParameter("FirstName");
        String LastName = request.getParameter("LastName");
        String Password = request.getParameter("psw");
        String Address = request.getParameter("Address");
        String Email = request.getParameter("Email");
        String Insurance = request.getParameter("Insurance");
        
        System.out.println("FirstName = " + FirstName);
        System.out.println("LastName = " + LastName);
        System.out.println("Password = " + Password);
        System.out.println("Address = " + Address);
        System.out.println("Email = " + Email);
        System.out.println("Insurance = " + Insurance);
        
        HttpSession session =  request.getSession();
        p1=(Patient) session.getAttribute("p1");
       
        p1.setpatId(id);
        p1.setpatPassword(Password);
        p1.setpatFirstName(FirstName);
        p1.setpatLastName(LastName);
        p1.setpatAddress(Address);
        p1.setpatEmail(Email);
        p1.setpatIns(Insurance);
        
        p1.updateDB();{
        RequestDispatcher requestDispatcher = request.getRequestDispatcher("PatientProfile.jsp");
        requestDispatcher.forward(request, response);
        }
            }else if (id.startsWith("D")){
                
                Dentist d1 = new Dentist();
        String FirstName = request.getParameter("FirstName");
        String LastName = request.getParameter("LastName");
        String Password = request.getParameter("psw");
        String Email = request.getParameter("Email");
        String Office = request.getParameter("Office");
        
        System.out.println("FirstName = " + FirstName);
        System.out.println("LastName = " + LastName);
        System.out.println("Password = " + Password);
        System.out.println("Email = " + Email);
        System.out.println("Office = " + Office);
        
        HttpSession session =  request.getSession();
        d1=(Dentist) session.getAttribute("d1");
        d1.setdenId(id);
        d1.setdenPassword(Password);
        d1.setdenFirstName(FirstName);
        d1.setdenLastName(LastName);
        d1.setdenEmail(Email);
        d1.setdenOffice(Office);
        
        d1.updateDB();
        RequestDispatcher requestDispatcher = request.getRequestDispatcher("DentistProfile.jsp");
        requestDispatcher.forward(request, response);
        
            }else{
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Error Page</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Error: " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
