/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import BO.Patient;
import BO.Dentist;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpSession;

/**
 * @author Ma'Caden Miles
 * 10/30/21-12/2/21
 * CIST 2373
 */
public class LoginServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            String id,pw; // fields
            
            id = request.getParameter("idtb");
            pw = request.getParameter("pwtb");
            System.out.println(" ID = "+id);
            System.out.println(" PW = "+pw);
            
            if(id.startsWith("A")){ // if Patient Logs In
                
                Patient p1;
                p1 = new Patient();
                p1.selectDB(id);
                System.out.println("ID             =   "+ p1.getpatId());
                System.out.println("Password     =   "+ p1.getpatPassword());
                
                String Ppwdb = null; 
                Ppwdb = p1.getpatPassword();
                
                
              if(Ppwdb.equals(pw)) {
            HttpSession ses1;
            ses1 = request.getSession();
            ses1.setAttribute("p1", p1);
            RequestDispatcher rd = request.getRequestDispatcher("PatientLanding.jsp");
            rd.forward(request, response);
            


        }else {
            //HttpSession ses1;
            //ses1 = request.getSession();
            //ses1.setAttribute("c1", c1);
             RequestDispatcher rd = request.getRequestDispatcher("ErrorPage.jsp"); // Wrong Patient errorpage
             rd.forward(request, response);

        }
                
            }else if(id.startsWith("D")){ // If Dentist Logs In
                Dentist d1;
                d1 = new Dentist();
                d1.selectDB(id);
                System.out.println("ID             =   "+ d1.getdenId());
                System.out.println("Password     =   "+ d1.getdenPassword());
                
                String Dpwdb = null; 
                Dpwdb = d1.getdenPassword();
                
                if(Dpwdb.equals(pw)) {
            HttpSession ses1;
            ses1 = request.getSession();
            ses1.setAttribute("d1", d1);
            RequestDispatcher rd = request.getRequestDispatcher("DentistLanding.jsp");
            rd.forward(request, response);
            


        }else {
            //HttpSession ses1;
            //ses1 = request.getSession();
            //ses1.setAttribute("c1", c1);
             RequestDispatcher rd = request.getRequestDispatcher("ErrorPage.jsp"); // Wrong Dentist errorpage
             rd.forward(request, response);

        }
            }else{
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Wrong ID</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Enter a Correct ID: " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
            }
            
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
